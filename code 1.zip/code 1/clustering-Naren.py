#!/usr/bin/env python
# coding: utf-8

# In[1]:


#Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns


# In[2]:


df = pd.read_csv('diabetesdata.csv')


# In[3]:


df.shape


# In[4]:


df.head()


# In[5]:


df.info()


# In[6]:


df.isna().sum()


# In[7]:


df.describe()


# In[8]:


sns.pairplot(df.iloc[:,[0,1,5]])


# In[9]:


from sklearn.preprocessing import StandardScaler
X=df.iloc[:,[1,5]].values
sc_X=StandardScaler()
X=sc_X.fit_transform(X)


# In[10]:


import os
os.environ["OMP_NUM_THREADS"]='1'


# In[11]:


from sklearn.cluster import KMeans
wcss=[]
for i in range(1,11):
    kmeans=KMeans(n_clusters=i,init='k-means++',random_state=42)
    kmeans.fit(X)
    wcss.append(kmeans.inertia_)
plt.plot(range(1,11),wcss)
plt.title('The Elbow Method')
plt.xlabel('Number of clusters')
plt.ylabel('WCSS')
plt.show()


# In[12]:


kmeans=KMeans(n_clusters=3,init='k-means++',random_state=42)
y_kmeans=kmeans.fit_predict(X)


# In[13]:


#Visualising the clusters
plt.figure(figsize=(8,8))
plt.scatter(X[y_kmeans==0,0],X[y_kmeans==0,1],s=100,c='blue',label='Cluster 1')
plt.scatter(X[y_kmeans==1,0],X[y_kmeans==1,1],s=100,c='red',label='Cluster 2')
plt.scatter(X[y_kmeans==2,0],X[y_kmeans==2,1],s=100,c='cyan',label='Cluster 3')
plt.scatter(kmeans.cluster_centers_[:,0],kmeans.cluster_centers_[:,1],s=300,c='magenta',label='Centroids')
plt.title('Clusters of Alcohol')
plt.xlabel('gulgose')
plt.ylabel('bmi')
plt.legend()
plt.show()


# In[14]:


from sklearn.neighbors import NearestNeighbors
neighbours=NearestNeighbors(n_neighbors=2)
distances,indices=neighbours.fit(X).kneighbors(X)
distances=distances[:,1]
distances=np.sort(distances,axis=0)
plt.plot(distances)


# In[18]:


from sklearn.cluster import DBSCAN
dbscan=DBSCAN(eps=0.50,min_samples=5)
y_dbscan=dbscan.fit_predict(X)


# In[19]:


y_dbscan


# In[21]:


plt.figure(figsize=(8,8))
plt.scatter(X[y_dbscan==0,0],X[y_dbscan==0,1],s=100,c='blue',label='Cluster 1')
plt.scatter(X[y_dbscan==1,0],X[y_dbscan==1,1],s=100,c='red',label='Cluster 2')
plt.scatter(X[y_dbscan==2,0],X[y_dbscan==2,1],s=100,c='cyan',label='Cluster 3')
plt.scatter(X[y_dbscan==-1,0],X[y_dbscan==-1,1],s=100,c='black',label='Noise')
plt.title('Clusters of Alcohol')
plt.xlabel('gulcouse')
plt.ylabel('bmi')
plt.legend()
plt.show()


# In[ ]:




